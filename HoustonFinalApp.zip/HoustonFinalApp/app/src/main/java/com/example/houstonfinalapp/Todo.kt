package com.example.houstonfinalapp

data class Todo(
    val title: String,
    var isChecked: Boolean = false
)